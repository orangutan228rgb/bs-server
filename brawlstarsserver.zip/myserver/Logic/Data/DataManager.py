import struct
from typing import Any, List, Dict

class Writer:
    def __init__(self, client):
        self.client = client
        self.buffer = bytearray()
        self.id = 0
    
    def writeByte(self, value: int):
        self.buffer += struct.pack('>B', value)
    
    def writeBoolean(self, value: bool):
        self.writeByte(1 if value else 0)
    
    def writeInt(self, value: int):
        self.buffer += struct.pack('>i', value)
    
    def writeUInt(self, value: int):
        self.buffer += struct.pack('>I', value)
    
    def writeLong(self, high: int, low: int):
        self.buffer += struct.pack('>q', (high << 32) | low)
    
    def writeString(self, value: str):
        if value is None:
            self.writeInt(-1)
        else:
            encoded = value.encode('utf-8')
            self.writeInt(len(encoded))
            self.buffer += encoded
    
    def writeVint(self, value: int):
        if value == 0:
            self.writeByte(0)
            return
        
        rotated = True if value < 0 else False
        value = abs(value)
        
        if value < 64:
            if rotated:
                self.writeByte(value | 0x80)
            else:
                self.writeByte(value)
            return
        
        buffer = bytearray()
        while value > 0:
            buffer.append(value & 0x7F)
            value >>= 7
        
        for i in range(len(buffer) - 1):
            buffer[i] |= 0x80
        
        if rotated:
            buffer[-1] |= 0x80
        
        self.buffer += buffer
    
    def writeDataReference(self, class_id: int, instance_id: int):
        self.writeVint(class_id)
        if class_id != 0:
            self.writeVint(instance_id)
    
    def get_packet(self) -> bytes:
        header = struct.pack('>H', len(self.buffer) + 2)
        packet_id = struct.pack('>H', self.id)
        return header + packet_id + self.buffer

class Reader:
    def __init__(self, data: bytes):
        self.data = data
        self.offset = 0
    
    def readByte(self) -> int:
        value = self.data[self.offset]
        self.offset += 1
        return value
    
    def readBoolean(self) -> bool:
        return self.readByte() != 0
    
    def readInt(self) -> int:
        value = struct.unpack('>i', self.data[self.offset:self.offset+4])[0]
        self.offset += 4
        return value
    
    def readUInt(self) -> int:
        value = struct.unpack('>I', self.data[self.offset:self.offset+4])[0]
        self.offset += 4
        return value
    
    def readLong(self) -> tuple:
        value = struct.unpack('>q', self.data[self.offset:self.offset+8])[0]
        self.offset += 8
        return (value >> 32, value & 0xFFFFFFFF)
    
    def readString(self) -> str:
        length = self.readInt()
        if length == -1 or length == 0:
            return ""
        value = self.data[self.offset:self.offset+length].decode('utf-8')
        self.offset += length
        return value
    
    def readVint(self) -> int:
        result = 0
        shift = 0
        while True:
            byte = self.readByte()
            result |= (byte & 0x7f) << shift
            shift += 7
            if not (byte & 0x80):
                break
        return result
    
    def readDataReference(self) -> tuple:
        class_id = self.readVint()
        instance_id = self.readVint() if class_id != 0 else 0
        return (class_id, instance_id)