class Player:
    def __init__(self, client):
        self.client = client
        self.HighID = 0
        self.LowID = 0
        self.Name = ""
        self.isRegistred = False
        self.level = 1
        self.doNotDisturb = False
        self.friends = []
        self.highestTrophies = 0
        self.brawlerID = 0
        self.skinID = 0
        self.selectedSkin = 0
        self.brawlerState = 0
        self.brawlersTrophies = {}
        self.selectedRandomSkin = False
        self.starpowerID = 0
        self.thumbnails = 0
        self.nameColor = 0
        self.trophies = 0
        self.experience = 0
        self.room_id = 0
        self.roomInfo = {}
        self.alliance_id = 0
        self.isBanned = False
        self.gems = 0
        self.coins = 0
        self.token = ""
    
    def encode(self):
        return {
            'name': self.Name,
            'IsRegistred': self.isRegistred,
            'level': self.level,
            'DoNotDisturb': self.doNotDisturb,
            'friend': self.friends,
            'highestTrophies': self.highestTrophies,
            'brawlerID': self.brawlerID,
            'skinID': self.skinID,
            'selectedSkin': self.selectedSkin,
            'brawlerState': self.brawlerState,
            'brawlersTrophies': self.brawlersTrophies,
            'selectedRandomSkin': self.selectedRandomSkin,
            'starpowerID': self.starpowerID,
            'playericon': self.thumbnails,
            'namecolor': self.nameColor,
            'trophies': self.trophies,
            'experience': self.experience,
            'gameroomID': self.room_id,
            'roomInfo': self.roomInfo,
            'allianceID': self.alliance_id,
            'isBanned': self.isBanned,
            'gems': self.gems,
            'coins': self.coins
        }