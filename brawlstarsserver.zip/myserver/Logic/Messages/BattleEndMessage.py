from Logic.Data.DataManager import Writer
from typing import Dict, Any, List

class BattleEndMessage(Writer):
    def __init__(self, client, player, players_list: Dict[str, Dict[str, Any]], battle_result: int, rewards: Dict[str, int]):
        super().__init__(client)
        self.id = 23456
        self.client = client
        self.player = player
        self.all_players = players_list
        self.battle_result = battle_result  # 0=defeat, 1=victory, 2=draw
        self.rewards = rewards
    
    def encode(self):
        self._write_battle_rewards()
        self._write_battle_flags()
        self._write_players_data()
        self._write_experience_data()
        self._write_milestone_progress()
        self._write_player_thumbnail()
        self._write_additional_flags()
    
    def _write_battle_rewards(self):
        self.writeVint(self.rewards.get('game_mode', 1))
        self.writeVint(self.battle_result)
        self.writeVint(self.rewards.get('tokens', 0))
        self.writeVint(self.rewards.get('trophies', 0))
        self.writeVint(self.rewards.get('power_play', 0))
        self.writeVint(self.rewards.get('doubled_tokens', 0))
        self.writeVint(self.rewards.get('token_event', 0))
        self.writeVint(self.rewards.get('token_doubler', 0))
        self.writeVint(self.rewards.get('special_event', 0))
        self.writeVint(self.rewards.get('epic_win', 0))
        self.writeVint(self.rewards.get('championship', 0))
    
    def _write_battle_flags(self):
        self.writeBoolean(False)
        self.writeVint(0)
        self.writeVint(0)
        self.writeBoolean(False)
        
        for _ in range(5):
            self.writeVint(0)
        
        self.writeByte(16)
        self.writeVint(-1)
        self.writeBoolean(False)
    
    def _write_players_data(self):
        self.writeVint(len(self.all_players))
        
        for player_data in self.all_players.values():
            self._write_single_player_data(player_data)
        
        self.writeVint(0)
    
    def _write_single_player_data(self, player_data: Dict[str, Any]):
        player_type = 1 if player_data["IsPlayer"] else (4 if player_data.get("Unknown") == 1 else 0)
        self.writeByte(player_type)
        
        self.writeDataReference(*player_data["BrawlerID"])
        self.writeDataReference(*player_data["SkinID"])
        
        self.writeVint(player_data.get("Trophies", 1250))
        self.writeVint(0)
        self.writeVint(player_data.get("PowerLevel", 10))
        self.writeVint(0)
        
        self.writeBoolean(player_data["IsPlayer"])
        if player_data["IsPlayer"]:
            self.writeLong(player_data.get("HighID", 0), player_data.get("LowID", 0))
        
        self.writeString(player_data["Name"])
        self.writeVint(100)
        self.writeVint(28000000 + player_data.get("Thumbnail", 0))
        self.writeVint(43000000 + player_data.get("NameColor", 0))
        self.writeVint(-1)
    
    def _write_experience_data(self):
        self.writeVint(0)
    
    def _write_milestone_progress(self):
        self.writeVint(2)
        self.writeVint(1)
        self.writeVint(self.player.trophies)
        self.writeVint(self.player.trophies + 50)
        self.writeVint(5)
        self.writeVint(9999999)
        self.writeVint(9999999)
    
    def _write_player_thumbnail(self):
        self.writeDataReference(28, self.player.thumbnails)
    
    def _write_additional_flags(self):
        self.writeBoolean(False)
        self.writeBoolean(False)
        self.writeVint(0)
        self.writeVint(0)
        self.writeBoolean(False)
        self.writeVint(-1)
        self.writeBoolean(False)