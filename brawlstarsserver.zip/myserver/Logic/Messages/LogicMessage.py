from Logic.Data.DataManager import Writer

class LoginMessage(Writer):
    def __init__(self, client, player):
        super().__init__(client)
        self.id = 20100
        self.player = player
    
    def encode(self):
        self.writeInt(0)  # Server protocol
        self.writeInt(0)  # Server build
        self.writeInt(0)  # Server content version
        
        self.writeString("")  # Server environment
        self.writeInt(0)  # Session count
        self.writeInt(0)  # Play time seconds
        self.writeInt(0)  # Days since started playing
        
        # Player data
        self.writeString(self.player.token)
        self.writeInt(self.player.HighID)
        self.writeInt(self.player.LowID)
        self.writeString(self.player.Name)
        self.writeString("")  # Facebook ID
        self.writeString("")  # Gamecenter ID
        
        self.writeInt(self.player.level)
        self.writeInt(self.player.experience)
        self.writeInt(self.player.trophies)
        self.writeInt(self.player.highestTrophies)
        
        # Resources
        self.writeInt(self.player.coins)
        self.writeInt(self.player.gems)
        
        # Brawlers count
        self.writeInt(len(self.player.brawlersTrophies))
        for brawler_id, trophies in self.player.brawlersTrophies.items():
            self.writeDataReference(16, brawler_id)  # Brawler class
            self.writeInt(trophies)  # Brawler trophies
            self.writeInt(10)  # Brawler power level
        
        # Unlocked brawlers
        self.writeInt(len(self.player.brawlersTrophies))
        for brawler_id in self.player.brawlersTrophies.keys():
            self.writeDataReference(16, brawler_id)
        
        # Player appearance
        self.writeDataReference(28, self.player.thumbnails)  # Thumbnail
        self.writeDataReference(43, self.player.nameColor)   # Name color
        
        # Region and language
        self.writeString("RU")  # Region
        self.writeString("ru")  # Language
        
        self.writeInt(0)  # Unknown
        self.writeInt(0)  # Unknown
        
        # Club data
        if self.player.alliance_id > 0:
            self.writeBoolean(True)
            self.writeInt(self.player.alliance_id)
            self.writeString("Test Club")  # Club name
            self.writeDataReference(8, 0)  # Club badge
            self.writeInt(1)  # Club role
            self.writeInt(10)  # Club members count
        else:
            self.writeBoolean(False)