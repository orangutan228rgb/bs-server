# Server/Core/GameServer.py (дополнения)
import logging

# Настройка логирования
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger('BrawlServer')

class GameServer:
    def __init__(self, host: str = '0.0.0.0', port: int = 9339):
        self.host = host
        self.port = port
        self.clients: Dict[int, Player] = {}
        self.db = DatabaseManager()
        self.server = None
    
    async def handle_client(self, reader, writer):
        addr = writer.get_extra_info('peername')
        logger.info(f"New connection from {addr}")
        
        try:
            while True:
                try:
                    header = await reader.read(4)
                    if not header:
                        break
                    
                    length = int.from_bytes(header[:2], 'big') - 2
                    packet_id = int.from_bytes(header[2:4], 'big')
                    
                    payload = await reader.read(length)
                    if len(payload) != length:
                        logger.warning(f"Incomplete packet from {addr}")
                        break
                    
                    await self.process_packet(packet_id, payload, writer)
                    
                except asyncio.CancelledError:
                    break
                except Exception as e:
                    logger.error(f"Error handling client {addr}: {e}")
                    break
                    
        except Exception as e:
            logger.error(f"Client connection error {addr}: {e}")
        finally:
            if writer:
                writer.close()
            logger.info(f"Connection closed from {addr}")