SERVER_CONFIG = {
    'host': '0.0.0.0',
    'port': 9339,
    'max_players': 1000,
    'ping_timeout': 30,
    'battle_timeout': 300,
    'database_path': 'player.sqlite'
}

BRAWLER_DATA = {
    0: {"name": "Shelly", "rarity": 0, "class": 0},
    1: {"name": "Colt", "rarity": 1, "class": 1},
    # Добавьте остальных бравлеров
}

SKIN_DATA = {
    0: {"name": "Default", "brawler_id": 0},
    1: {"name": "Bandita Shelly", "brawler_id": 0},
    # Добавьте остальные скины
}